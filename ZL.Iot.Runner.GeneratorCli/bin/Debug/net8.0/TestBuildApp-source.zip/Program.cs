using ZL.Iot.Runner;
using ZL.Iot.Runner.Configuration;
using ZL.Iot.Runner.Runtime;
using Microsoft.Extensions.Logging;

namespace TestBuildApp;

public static class Program
{
    public static int Main(string[] args)
    {
        var configPath = args.Length > 0 ? args[0] : "./runner.config.json";
        var config = ConfigLoader.Load(configPath);
        using var loggerFactory = LoggerFactory.Create(b => b.AddConsole().SetMinimumLevel(LogLevel.Information));
        var runner = new DeviceRunner(config, loggerFactory.CreateLogger<DeviceRunner>());

        using var cts = new CancellationTokenSource();
        Console.CancelKeyPress += (s, e) => { e.Cancel = true; cts.Cancel(); };
        runner.Run(cts.Token);
        return 0;
    }
}
