@echo off
echo Building {{ project_name }}...
dotnet build -c Release
echo Done. Output: bin\Release\
pause